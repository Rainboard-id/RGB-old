# LiquidCrystal_I2C

LiquidCrystal Arduino library for I2C LCD displays

This repo is being transfered to GitLab at https://gitlab.com/tandembyte/liquidcrystal_i2c
