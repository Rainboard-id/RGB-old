#ifndef IRREMOTETOOLS_H
#define IRREMOTETOOLS_H

extern void beginIRremote();

extern bool IRrecived();

extern void resumeIRremote();

extern unsigned long getIRresult();

#endif